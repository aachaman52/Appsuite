"""AppSuite Desktop package."""
