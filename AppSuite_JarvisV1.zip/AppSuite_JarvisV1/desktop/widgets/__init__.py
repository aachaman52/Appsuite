"""Desktop widgets package."""
