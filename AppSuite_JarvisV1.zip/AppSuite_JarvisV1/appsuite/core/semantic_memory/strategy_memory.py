from __future__ import annotations
from typing import Any, Dict, List

class StrategyMemory:
    """Stores high-level planning strategies from JarvisBrain in SQLite."""
    def __init__(self, db=None):
        self.db = db
        self._local_strategies = []

    def add_strategy(self, prompt: str, strategy: Dict[str, Any], outcome: str = "success"):
        if self.db and hasattr(self.db, "add_strategy_memory"):
            self.db.add_strategy_memory(prompt, strategy, outcome)
        else:
            self._local_strategies.append({"prompt": prompt, "strategy": strategy, "outcome": outcome})

    def store_strategy(self, strategy: Dict[str, Any]):
        prompt = strategy.get("prompt", "default_prompt")
        self.add_strategy(prompt, strategy, "success")

    # Compatibility method for the original codebase
    def add_strategy_compat(self, strategy: Dict[str, Any]):
        self.store_strategy(strategy)

    def get_strategies_for_prompt(self, prompt: str) -> List[Dict[str, Any]]:
        if self.db and hasattr(self.db, "get_strategy_memories"):
            return self.db.get_strategy_memories(prompt)
        return [s for s in self._local_strategies if s["prompt"] == prompt]
