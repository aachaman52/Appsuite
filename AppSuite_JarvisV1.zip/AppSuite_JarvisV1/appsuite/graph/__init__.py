# Graph package backward compatibility
