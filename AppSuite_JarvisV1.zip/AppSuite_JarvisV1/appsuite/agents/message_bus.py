import queue
import threading
from typing import Dict, List, Any

class MessageBus:
    """Thread-safe Pub-Sub Message Bus for agents."""
    def __init__(self):
        self._subscribers: Dict[str, List[queue.Queue]] = {}
        self._lock = threading.Lock()

    def subscribe(self, topic: str) -> queue.Queue:
        q = queue.Queue()
        with self._lock:
            if topic not in self._subscribers:
                self._subscribers[topic] = []
            self._subscribers[topic].append(q)
        return q

    def send(self, topic: str, message: Any) -> None:
        with self._lock:
            # Send to specific topic subscribers
            if topic in self._subscribers:
                for q in self._subscribers[topic]:
                    q.put(message)
            # Send to broadcast topic subscribers if any
            if topic != "broadcast" and "broadcast" in self._subscribers:
                for q in self._subscribers["broadcast"]:
                    q.put({"topic": topic, "message": message})
